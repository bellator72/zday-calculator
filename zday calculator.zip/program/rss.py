def food():
    import os
    os.system("cls")
    print("FOOD RSS")
    print("Enter a value for each rss with at least a 0 on up.")
    print("\n" * 1)
    a = int(input("1,000: "))
    b = int(input("3,000: "))
    c = int(input("5,000: "))
    d = int(input("10,000: "))
    e = int(input("50,000: "))
    f = int(input("150,000: "))
    g = int(input("500,000: "))
    i = int(input("1,500,000: "))
    z = (int(a) * 1000)+(int(b) * 3000)+(int(c) * 5000)+(int(d) * 10000)+(int(e) * 50000)+(int(f) * 150000)+(int(g) * 500000)+(int(i) * 1500000)
    print("Total food",place_value(z))
    input("Press enter to return")


def oil():
    import os
    os.system("cls")
    print("OIL RSS")
    print("Enter a value for each rss with at least a 0 on up.")
    print("\n" * 1)
    a = int(input("1,000: "))
    b = int(input("3,000: "))
    c = int(input("5,000: "))
    d = int(input("10,000: "))
    e = int(input("30,000: "))
    f = int(input("50,000: "))
    g = int(input("150,000: "))
    h = int(input("500,000: "))
    i = int(input("1,500,000: "))
    z = (int(a) * 1000) + (int(b) * 3000) + (int(c) * 5000) + (int(d) * 10000) + (int(e) * 30000) + (int(f) * 50000) + (int(g) * 150000) + (int(h) * 500000) + (int(i) * 1500000)
    print("Total food", place_value(z))
    input("Press enter to return")


def iron():
    import os
    os.system("cls")
    print("IRON RSS")
    print("Enter a value for each rss with at least a 0 on up.")
    print("\n" * 1)
    a = int(input("200: "))
    b = int(input("600: "))
    c = int(input("1,000: "))
    d = int(input("2,000: "))
    e = int(input("10,000: "))
    f = int(input("100,000: "))
    g = int(input("300,000: "))
    z = (int(a) * 200) + (int(b) * 600) + (int(c) * 1000) + (int(d) * 2000) + (int(e) * 10000) + (int(f) * 100000) + (int(g) * 300000)
    print("Total food", place_value(z))
    input("Press enter to return")


def alloy():
    import os
    os.system("cls")
    print("ALLOY RSS")
    print("Enter a value for each rss with at least a 0 on up.")
    print("\n" * 1)
    a = int(input("50: "))
    b = int(input("150: "))
    c = int(input("250: "))
    d = int(input("500: "))
    e = int(input("2,500: "))
    f = int(input("25,000: "))
    g = int(input("75,000: "))
    z = (int(a) * 50) + (int(b) * 150) + (int(c) * 250) + (int(d) * 500) + (int(e) * 2500) + (int(f) * 25000) + (int(g) * 75000)
    print("Total food", place_value(z))
    input("Press enter to return")

def place_value(z):
    return("{:,}".format(z))


