1. The first thing you'll have to do is install python onto your computer.
Go to https://www.python.org/ and download the python file that's right for you.
I have included a 64bit install for you called python-3.7.2-amd64 
this is a good video to install python https://youtu.be/dX2-V2BocqQ
2. run program called Calulator and that's it.

hope you like this and have fun with it..
this is just the beta version check back for other version later on down the road
if there are any bugs please post them. 
thank you for trying my calculator
