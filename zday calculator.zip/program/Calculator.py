
for i in range(100):
    import os
    os.system("cls")
    print("Hello and welcome to my z-day resource calculator!!!!!")
    print("Which RSS can I help you with today?")
    x = input("Type which RSS you'd like to calculate: food, oil, iron, alloy, or exit: ")


    if(x=='food'):
        import rss
        rss.food()
    elif(x=='oil'):
        import rss
        rss.oil()
    elif(x=='iron'):
        import rss
        rss.iron()
    elif(x=='alloy'):
        import rss
        rss.alloy()
    elif(x=='exit'):
        print("Goodbye :)")
        break
    else:
        print("invalid entry try again")
